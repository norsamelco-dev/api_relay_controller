const express = require('express');
const cors = require('cors');
require('dotenv').config();
const { pool, testConnection } = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Test database connection on startup
testConnection();

// Root endpoint - Arduino can ping this to check if API is alive
app.get('/', (req, res) => {
    res.json({ 
        status: 'online', 
        message: 'Arduino API Server is running',
        timestamp: new Date().toISOString()
    });
});

// Database status endpoint
app.get('/status', async (req, res) => {
    try {
        const connection = await pool.getConnection();
        connection.release();
        res.json({ 
            status: 'connected', 
            database: process.env.DB_NAME,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({ 
            status: 'error', 
            message: 'Database connection failed',
            error: error.message 
        });
    }
});

// Arduino sensor data endpoint - POST data from Arduino
app.post('/sensor-data', async (req, res) => {
    try {
        const { sensor_type, value, unit, location } = req.body;
        
        if (!sensor_type || value === undefined) {
            return res.status(400).json({ 
                error: 'Missing required fields: sensor_type and value are required' 
            });
        }

        const query = `
            INSERT INTO sensor_readings (sensor_type, value, unit, location, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        `;
        
        const [result] = await pool.execute(query, [sensor_type, value, unit || 'N/A', location || 'unknown']);
        
        res.json({ 
            success: true, 
            id: result.insertId,
            message: 'Sensor data saved successfully'
        });
    } catch (error) {
        console.error('Error saving sensor data:', error);
        res.status(500).json({ 
            error: 'Failed to save sensor data',
            message: error.message 
        });
    }
});

// Get latest sensor readings - Arduino can fetch this
app.get('/sensor-data/latest', async (req, res) => {
    try {
        const { sensor_type, limit = 10 } = req.query;
        
        let query = `
            SELECT * FROM sensor_readings 
            WHERE 1=1
        `;
        
        const params = [];
        
        if (sensor_type) {
            query += ' AND sensor_type = ?';
            params.push(sensor_type);
        }
        
        query += ' ORDER BY created_at DESC LIMIT ?';
        params.push(parseInt(limit));
        
        const [rows] = await pool.execute(query, params);
        
        res.json({ 
            success: true, 
            count: rows.length,
            data: rows 
        });
    } catch (error) {
        console.error('Error fetching sensor data:', error);
        res.status(500).json({ 
            error: 'Failed to fetch sensor data',
            message: error.message 
        });
    }
});

// Arduino device registration endpoint
app.post('/device/register', async (req, res) => {
    try {
        const { device_id, device_name, device_type, location } = req.body;
        
        if (!device_id || !device_name) {
            return res.status(400).json({ 
                error: 'Missing required fields: device_id and device_name are required' 
            });
        }

        const query = `
            INSERT INTO devices (device_id, device_name, device_type, location, registered_at) 
            VALUES (?, ?, ?, ?, NOW())
            ON DUPLICATE KEY UPDATE 
            device_name = VALUES(device_name), 
            device_type = VALUES(device_type), 
            location = VALUES(location),
            last_seen = NOW()
        `;
        
        const [result] = await pool.execute(query, [device_id, device_name, device_type || 'arduino', location || 'unknown']);
        
        res.json({ 
            success: true, 
            device_id,
            message: result.affectedRows === 1 ? 'Device registered successfully' : 'Device updated successfully'
        });
    } catch (error) {
        console.error('Error registering device:', error);
        res.status(500).json({ 
            error: 'Failed to register device',
            message: error.message 
        });
    }
});

// Get device status
app.get('/device/:device_id/status', async (req, res) => {
    try {
        const { device_id } = req.params;
        
        const query = 'SELECT * FROM devices WHERE device_id = ?';
        const [rows] = await pool.execute(query, [device_id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ 
                error: 'Device not found' 
            });
        }
        
        res.json({ 
            success: true, 
            device: rows[0] 
        });
    } catch (error) {
        console.error('Error fetching device status:', error);
        res.status(500).json({ 
            error: 'Failed to fetch device status',
            message: error.message 
        });
    }
});

// Simple LED control endpoint for Arduino
app.post('/led/control', async (req, res) => {
    try {
        const { device_id, state, pin = 13 } = req.body;
        
        if (!device_id || state === undefined) {
            return res.status(400).json({ 
                error: 'Missing required fields: device_id and state are required' 
            });
        }

        const query = `
            INSERT INTO led_controls (device_id, pin, state, controlled_at) 
            VALUES (?, ?, ?, NOW())
        `;
        
        const [result] = await pool.execute(query, [device_id, pin, state]);
        
        res.json({ 
            success: true, 
            id: result.insertId,
            message: `LED ${state ? 'turned ON' : 'turned OFF'} successfully`
        });
    } catch (error) {
        console.error('Error controlling LED:', error);
        res.status(500).json({ 
            error: 'Failed to control LED',
            message: error.message 
        });
    }
});

// ==================== RELAY CONTROL ENDPOINTS ====================

// Control individual relay (trigger 3-second cycle)
app.post('/relay/:relay_number/trigger', async (req, res) => {
    try {
        const { relay_number } = req.params;
        const { device_id, duration = 3000 } = req.body;  // duration in milliseconds
        
        const relayNum = parseInt(relay_number);
        
        if (!device_id) {
            return res.status(400).json({ 
                error: 'Missing required field: device_id' 
            });
        }
        
        if (relayNum < 1 || relayNum > 4) {
            return res.status(400).json({ 
                error: 'Invalid relay number. Must be between 1 and 4' 
            });
        }

        const query = `
            INSERT INTO relay_controls (device_id, relay_number, action, duration, controlled_at) 
            VALUES (?, ?, 'trigger', ?, NOW())
        `;
        
        const [result] = await pool.execute(query, [device_id, relayNum, duration]);
        
        res.json({ 
            success: true, 
            id: result.insertId,
            relay_number: relayNum,
            action: 'trigger',
            duration: duration,
            message: `Relay ${relayNum} triggered for ${duration/1000} seconds`
        });
    } catch (error) {
        console.error('Error triggering relay:', error);
        res.status(500).json({ 
            error: 'Failed to trigger relay',
            message: error.message 
        });
    }
});

// Reset individual relay (turn OFF immediately)
app.post('/relay/:relay_number/reset', async (req, res) => {
    try {
        const { relay_number } = req.params;
        const { device_id } = req.body;
        
        const relayNum = parseInt(relay_number);
        
        if (!device_id) {
            return res.status(400).json({ 
                error: 'Missing required field: device_id' 
            });
        }
        
        if (relayNum < 1 || relayNum > 4) {
            return res.status(400).json({ 
                error: 'Invalid relay number. Must be between 1 and 4' 
            });
        }

        const query = `
            INSERT INTO relay_controls (device_id, relay_number, action, duration, controlled_at) 
            VALUES (?, ?, 'reset', 0, NOW())
        `;
        
        const [result] = await pool.execute(query, [device_id, relayNum]);
        
        res.json({ 
            success: true, 
            id: result.insertId,
            relay_number: relayNum,
            action: 'reset',
            message: `Relay ${relayNum} reset successfully`
        });
    } catch (error) {
        console.error('Error resetting relay:', error);
        res.status(500).json({ 
            error: 'Failed to reset relay',
            message: error.message 
        });
    }
});

// Get relay status and history
app.get('/relay/status', async (req, res) => {
    try {
        const { device_id, relay_number, limit = 10 } = req.query;
        
        let query = `
            SELECT rc.*, d.device_name 
            FROM relay_controls rc
            JOIN devices d ON rc.device_id = d.device_id
            WHERE 1=1
        `;
        
        const params = [];
        
        if (device_id) {
            query += ' AND rc.device_id = ?';
            params.push(device_id);
        }
        
        if (relay_number) {
            query += ' AND rc.relay_number = ?';
            params.push(parseInt(relay_number));
        }
        
        query += ' ORDER BY rc.controlled_at DESC LIMIT ?';
        params.push(parseInt(limit));
        
        const [rows] = await pool.execute(query, params);
        
        res.json({ 
            success: true, 
            count: rows.length,
            data: rows 
        });
    } catch (error) {
        console.error('Error fetching relay status:', error);
        res.status(500).json({ 
            error: 'Failed to fetch relay status',
            message: error.message 
        });
    }
});

// Control all relays at once
app.post('/relay/all', async (req, res) => {
    try {
        const { device_id, action } = req.body;  // action: 'trigger_all', 'reset_all'
        
        if (!device_id || !action) {
            return res.status(400).json({ 
                error: 'Missing required fields: device_id and action' 
            });
        }
        
        if (action !== 'trigger_all' && action !== 'reset_all') {
            return res.status(400).json({ 
                error: 'Invalid action. Must be trigger_all or reset_all' 
            });
        }
        
        const results = [];
        
        for (let relayNum = 1; relayNum <= 4; relayNum++) {
            const query = `
                INSERT INTO relay_controls (device_id, relay_number, action, duration, controlled_at) 
                VALUES (?, ?, ?, ?, NOW())
            `;
            
            const duration = action === 'trigger_all' ? 3000 : 0;
            const relayAction = action === 'trigger_all' ? 'trigger' : 'reset';
            
            const [result] = await pool.execute(query, [device_id, relayNum, relayAction, duration]);
            
            results.push({
                relay_number: relayNum,
                action: relayAction,
                id: result.insertId
            });
        }
        
        res.json({ 
            success: true, 
            action: action,
            results: results,
            message: `All relays ${action.replace('_', ' ')}ed successfully`
        });
    } catch (error) {
        console.error('Error controlling all relays:', error);
        res.status(500).json({ 
            error: 'Failed to control all relays',
            message: error.message 
        });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ 
        error: 'Something went wrong!',
        message: err.message 
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ 
        error: 'Endpoint not found',
        available_endpoints: [
            'GET /',
            'GET /status',
            'POST /sensor-data',
            'GET /sensor-data/latest',
            'POST /device/register',
            'GET /device/:device_id/status',
            'POST /led/control',
            'POST /relay/:relay_number/trigger',
            'POST /relay/:relay_number/reset',
            'GET /relay/status',
            'POST /relay/all'
        ]
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Arduino API Server running on port ${PORT}`);
    console.log(`📡 Server ready for Arduino connections`);
});

module.exports = app;