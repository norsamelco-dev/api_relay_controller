# Arduino API Server

A Node.js API server designed specifically for Arduino projects with MySQL database integration.

## 🚀 Features

- **Database Connection**: Connected to your local MySQL database (`norsamel_server_arduino_v1`)
- **Arduino-Friendly Endpoints**: Simple JSON-based API perfect for Arduino HTTP requests
- **Sensor Data Management**: Store and retrieve sensor readings
- **Device Registration**: Register and manage Arduino devices
- **LED Control**: Control LEDs and store control history
- **Real-time Status**: Check server and database status

## 📡 API Endpoints

### Server Status
```
GET /              - Check if server is online
GET /status        - Check database connection status
```

### Sensor Data
```
POST /sensor-data              - Submit sensor data from Arduino
GET  /sensor-data/latest       - Get latest sensor readings
```

### Device Management
```
POST /device/register          - Register Arduino device
GET  /device/:device_id/status - Get device status
```

### LED Control
```
POST /led/control              - Control LED state
```

## 🔧 Arduino Code Examples

### Basic HTTP GET Request
```cpp
#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* serverUrl = "http://YOUR_SERVER_IP:3000";

void setup() {
    Serial.begin(115200);
    WiFi.begin(ssid, password);
    
    while (WiFi.status() != WL_CONNECTED) {
        delay(1000);
        Serial.println("Connecting to WiFi...");
    }
    
    Serial.println("Connected to WiFi!");
}

void loop() {
    if (WiFi.status() == WL_CONNECTED) {
        HTTPClient http;
        
        // Check server status
        http.begin(String(serverUrl) + "/status");
        int httpCode = http.GET();
        
        if (httpCode > 0) {
            String payload = http.getString();
            Serial.println("Server Status: " + payload);
        }
        
        http.end();
    }
    
    delay(10000); // Wait 10 seconds
}
```

### Send Sensor Data to Server
```cpp
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* serverUrl = "http://YOUR_SERVER_IP:3000";

void sendSensorData(float temperature, float humidity) {
    if (WiFi.status() == WL_CONNECTED) {
        HTTPClient http;
        
        // Create JSON payload
        StaticJsonDocument<200> doc;
        doc["sensor_type"] = "temperature";
        doc["value"] = temperature;
        doc["unit"] = "°C";
        doc["location"] = "Office Room";
        
        String jsonString;
        serializeJson(doc, jsonString);
        
        // Send POST request
        http.begin(String(serverUrl) + "/sensor-data");
        http.addHeader("Content-Type", "application/json");
        
        int httpCode = http.POST(jsonString);
        
        if (httpCode > 0) {
            Serial.println("Data sent successfully!");
            Serial.println("Response: " + http.getString());
        } else {
            Serial.println("Error sending data: " + String(httpCode));
        }
        
        http.end();
    }
}
```

### Register Arduino Device
```cpp
void registerDevice(String deviceId, String deviceName) {
    if (WiFi.status() == WL_CONNECTED) {
        HTTPClient http;
        
        StaticJsonDocument<200> doc;
        doc["device_id"] = deviceId;
        doc["device_name"] = deviceName;
        doc["device_type"] = "arduino_uno";
        doc["location"] = "Office Room";
        
        String jsonString;
        serializeJson(doc, jsonString);
        
        http.begin(String(serverUrl) + "/device/register");
        http.addHeader("Content-Type", "application/json");
        
        int httpCode = http.POST(jsonString);
        
        if (httpCode > 0) {
            Serial.println("Device registered successfully!");
        }
        
        http.end();
    }
}
```

## 🗄️ Database Schema

The API uses the following database tables:

- **sensor_readings**: Stores sensor data from Arduino
- **devices**: Manages registered Arduino devices  
- **led_controls**: Tracks LED control history
- **system_logs**: General system logging

## 🚀 Getting Started

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Configure Database**
   - Database credentials are already set in `.env` file
   - Run the SQL schema in `database_schema.sql` to create tables

3. **Start Server**
   ```bash
   node server.js
   ```

4. **Test Connection**
   ```bash
   node test-db.js
   ```

## 📋 Environment Variables

The `.env` file contains:
```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=Confirmaccess@2026
DB_NAME=norsamel_server_arduino_v1
DB_PORT=3306
PORT=3000
```

## 🔗 Arduino HTTP Library

For Arduino projects, you'll need:
- **WiFi Library**: For network connectivity
- **HTTPClient Library**: For HTTP requests
- **ArduinoJson Library**: For JSON parsing/serialization

Install via Arduino Library Manager:
- WiFi (built-in)
- ArduinoJson by Benoit Blanchon

## 🧪 Testing the API

You can test the API endpoints using curl or Postman:

```bash
# Test server status
curl http://localhost:3000/status

# Send sensor data
curl -X POST http://localhost:3000/sensor-data \
  -H "Content-Type: application/json" \
  -d '{"sensor_type":"temperature","value":25.5,"unit":"°C","location":"Office"}'

# Get latest sensor readings
curl http://localhost:3000/sensor-data/latest

# Register device
curl -X POST http://localhost:3000/device/register \
  -H "Content-Type: application/json" \
  -d '{"device_id":"arduino_001","device_name":"Arduino Uno #1"}'
```

## 🛡️ Security Notes

- Keep your database credentials secure
- Use HTTPS in production (consider SSL/TLS)
- Implement rate limiting for production use
- Validate all input data on the server
- Consider API key authentication for Arduino devices

## 🐛 Troubleshooting

### Database Connection Issues
- Ensure MySQL is running on localhost
- Verify database credentials in `.env` file
- Check if database `norsamel_server_arduino_v1` exists

### Arduino Connection Issues
- Check WiFi credentials in Arduino sketch
- Ensure server IP address is correct
- Verify firewall settings allow port 3000

### Server Issues
- Check if port 3000 is available
- Verify all dependencies are installed
- Check console logs for error messages