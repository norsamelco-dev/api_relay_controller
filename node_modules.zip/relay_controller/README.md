# Arduino 4-Channel Relay Control System

A complete Arduino-based relay control system with independent relay operation and API integration for remote control.

## 🎯 Features

- **4 Independent Relays**: Each relay operates separately without blocking others
- **3-Second Auto-Cycle**: Relays automatically turn OFF after 3 seconds
- **Non-Blocking Code**: Uses millis() timing instead of delay() functions
- **API Integration**: Remote control via HTTP requests to Node.js server
- **Status Reporting**: Real-time relay status and history tracking
- **WiFi Connectivity**: Wireless control and monitoring
- **Serial Control**: Manual control via serial commands for testing

## 📡 API Endpoints

### Relay Control
```
POST /relay/:relay_number/trigger    - Trigger relay for 3 seconds
POST /relay/:relay_number/reset      - Reset relay immediately
POST /relay/all                      - Control all relays at once
GET  /relay/status                   - Get relay control history
```

### System Status
```
GET  /status                         - Check server/database status
POST /device/register               - Register Arduino device
GET  /device/:device_id/status    - Get device status
```

## 🔧 Hardware Requirements

- **Arduino Board**: Uno, Mega, or ESP32 (ESP32 recommended for WiFi)
- **4-Channel Relay Module**: 5V or 3.3V depending on your Arduino
- **Power Supply**: Appropriate voltage for your setup
- **Jumper Wires**: For connections
- **WiFi Access**: For remote control functionality

## 📋 Pin Connections

| Relay | Arduino Pin | Function |
|-------|-------------|----------|
| R1    | Pin 2       | Channel 1 Control |
| R2    | Pin 3       | Channel 2 Control |
| R3    | Pin 4       | Channel 3 Control |
| R4    | Pin 5       | Channel 4 Control |

## 🚀 Installation & Setup

### 1. Install Required Libraries

Open Arduino IDE → Tools → Manage Libraries, install:
- **ArduinoJson** by Benoit Blanchon
- **WiFi** (built-in for ESP32)

### 2. Configure WiFi and Server

Edit the Arduino sketch and update:
```cpp
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
const char* serverUrl = "http://YOUR_SERVER_IP:3000";
```

### 3. Upload Code

Choose the appropriate sketch for your needs:
- **[simple_relay_test.ino](simple_relay_test/simple_relay_test.ino)** - Basic testing without WiFi
- **[relay_controller.ino](relay_controller.ino)** - Full WiFi version with API integration
- **[relay_controller_api.ino](relay_controller_api/relay_controller_api.ino)** - Advanced API integration

## 🎮 Usage Examples

### Serial Commands (Testing)

```
R1=1      - Trigger relay 1 (3-second ON cycle)
R2=0      - Reset relay 2 (turn OFF immediately)
STATUS    - Show current status of all relays
RESET     - Reset all relays to OFF
```

### API Requests (Remote Control)

**Trigger Relay 1:**
```bash
curl -X POST http://localhost:3000/relay/1/trigger \
  -H "Content-Type: application/json" \
  -d '{"device_id": "relay_controller_001"}'
```

**Reset Relay 3:**
```bash
curl -X POST http://localhost:3000/relay/3/reset \
  -H "Content-Type: application/json" \
  -d '{"device_id": "relay_controller_001"}'
```

**Trigger All Relays:**
```bash
curl -X POST http://localhost:3000/relay/all \
  -H "Content-Type: application/json" \
  -d '{"device_id": "relay_controller_001", "action": "trigger_all"}'
```

**Get Relay Status History:**
```bash
curl "http://localhost:3000/relay/status?device_id=relay_controller_001&limit=5"
```

## ⚡ How It Works

### Independent Operation
Each relay runs its own timing cycle:
1. **Trigger**: Set `relayStatus[i] = 1`
2. **Turn ON**: Relay activates immediately
3. **Timing**: Start 3-second timer using `millis()`
4. **Auto-OFF**: Turn OFF after 3 seconds, reset status to 0

### Non-Blocking Code
- Uses `millis()` instead of `delay()`
- Each relay has independent timing variables
- Main loop continues running while relays are active
- No interference between relay operations

### API Integration
1. **Registration**: Arduino registers with server on startup
2. **Status Reporting**: Relay state changes sent to server
3. **Command Processing**: Server can send commands (future enhancement)
4. **History Logging**: All relay actions stored in database

## 📊 Serial Monitor Output

```
=================================
4-Channel Relay Controller v1.0
=================================
Initializing relay pins...
Relay 1 on pin 2 - Initialized
Relay 2 on pin 3 - Initialized
Relay 3 on pin 4 - Initialized
Relay 4 on pin 5 - Initialized
✅ All relays initialized to OFF state
Connecting to WiFi........
Connected!
IP address: 192.168.1.100
Registering device with server...
✅ Device registered successfully!
Setup complete! Starting main loop...
=================================

=== RELAY STATUS ===
Relay 1: OFF (Ready)
Relay 2: OFF (Ready)
Relay 3: OFF (Ready)
Relay 4: OFF (Ready)
WiFi: Connected | Server: Online
====================

🔥 Relay 1 turned ON - 3 second cycle started
⭕ Relay 1 turned OFF - Cycle complete
```

## 🔗 Arduino Code Structure

### Core Functions
- `processRelayControls()` - Main relay timing logic
- `triggerRelay()` - Start relay cycle
- `resetRelay()` - Stop relay immediately
- `handleSerialCommands()` - Process serial input
- `handleApiCommunication()` - Manage server communication

### Timing Variables
- `relayStatus[4]` - Current status (0=ready, 1=running)
- `relayState[4]` - Current ON/OFF state
- `relayStartTime[4]` - When relay was turned ON
- `RELAY_ON_DURATION` - 3-second constant

## 🧪 Testing

### Basic Test (No WiFi)
1. Upload `simple_relay_test/simple_relay_test.ino`
2. Open Serial Monitor (115200 baud)
3. Send commands: `R1=1`, `R2=1`, `STATUS`, `RESET`

### Full System Test (With WiFi)
1. Start Node.js server: `node server.js`
2. Upload `relay_controller_api/relay_controller_api.ino`
3. Check server registration
4. Use API endpoints to control relays
5. Monitor serial output for status updates

## 🛡️ Safety Notes

- **Electrical Safety**: Be careful with high voltage connections
- **Relay Ratings**: Don't exceed relay current/voltage ratings
- **Power Supply**: Use appropriate power supply for your relays
- **WiFi Security**: Use secure WiFi networks for remote control
- **Testing**: Test with low voltage first before connecting high power devices

## 🔧 Troubleshooting

### WiFi Connection Issues
- Check WiFi credentials in sketch
- Ensure server IP address is correct
- Verify firewall allows port 3000

### Relay Not Working
- Check pin connections
- Verify relay module power supply
- Test with simple blink sketch first

### API Communication Issues
- Check server is running: `node server.js`
- Verify device registration
- Check serial monitor for error messages

## 📈 Future Enhancements

- **Web Dashboard**: Create a web interface for relay control
- **Mobile App**: Develop mobile app for remote control
- **Scheduling**: Add time-based relay scheduling
- **Sensor Integration**: Add sensors to trigger relays automatically
- **Email Alerts**: Send notifications for relay status changes
- **Multiple Controllers**: Support multiple Arduino controllers

## 📚 Related Files

- **[server.js](../server.js)** - Node.js API server
- **[database_schema.sql](../database_schema.sql)** - Database setup
- **[arduino_client_example.ino](../arduino_client_example.ino)** - Basic Arduino API client

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section
2. Review serial monitor output
3. Verify all connections and configurations
4. Test with simpler examples first