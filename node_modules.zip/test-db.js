const { testConnection } = require('./database');

console.log('🔍 Testing database connection...');

testConnection().then((connected) => {
    if (connected) {
        console.log('✅ Database connection test passed!');
        console.log('🚀 You can now start the server with: node server.js');
    } else {
        console.log('❌ Database connection test failed!');
        console.log('💡 Please check:');
        console.log('   - MySQL server is running');
        console.log('   - Database credentials in .env file');
        console.log('   - Database "norsamel_server_arduino_v1" exists');
    }
    process.exit(connected ? 0 : 1);
}).catch(error => {
    console.error('❌ Test failed with error:', error);
    process.exit(1);
});