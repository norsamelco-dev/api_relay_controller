const axios = require('axios');

const BASE_URL = 'http://localhost:3000';

async function testAPI() {
    console.log('Testing API endpoints...\n');
    
    // Test 1: Root endpoint
    try {
        const response1 = await axios.get(`${BASE_URL}/`);
        console.log('✅ GET / - Success');
        console.log('   Response:', response1.data);
    } catch (error) {
        console.log('❌ GET / - Failed:', error.message);
    }
    
    console.log('');
    
    // Test 2: Status endpoint
    try {
        const response2 = await axios.get(`${BASE_URL}/status`);
        console.log('✅ GET /status - Success');
        console.log('   Response:', response2.data);
    } catch (error) {
        console.log('❌ GET /status - Failed:', error.message);
    }
    
    console.log('');
    
    // Test 3: POST sensor-data
    try {
        const response3 = await axios.post(`${BASE_URL}/sensor-data`, {
            sensor_type: 'temperature',
            value: 25.5,
            unit: '°C',
            location: 'Office'
        });
        console.log('✅ POST /sensor-data - Success');
        console.log('   Response:', response3.data);
    } catch (error) {
        console.log('❌ POST /sensor-data - Failed:', error.message);
    }
    
    console.log('');
    
    // Test 4: GET sensor-data/latest
    try {
        const response4 = await axios.get(`${BASE_URL}/sensor-data/latest`);
        console.log('✅ GET /sensor-data/latest - Success');
        console.log('   Response:', response4.data);
    } catch (error) {
        console.log('❌ GET /sensor-data/latest - Failed:', error.message);
    }
    
    console.log('');
    
    // Test 5: POST device/register
    try {
        const response5 = await axios.post(`${BASE_URL}/device/register`, {
            device_id: 'test_arduino_001',
            device_name: 'Test Arduino',
            device_type: 'esp32',
            location: 'Test Lab'
        });
        console.log('✅ POST /device/register - Success');
        console.log('   Response:', response5.data);
    } catch (error) {
        console.log('❌ POST /device/register - Failed:', error.message);
    }
    
    console.log('\n--- All tests completed ---');
}

testAPI();
