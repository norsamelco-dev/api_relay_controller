-- Database schema for Arduino API Server
-- Database: norsamel_server_arduino_v1

-- Create sensor_readings table for storing Arduino sensor data
CREATE TABLE IF NOT EXISTS sensor_readings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sensor_type VARCHAR(50) NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    unit VARCHAR(20) DEFAULT 'N/A',
    location VARCHAR(100) DEFAULT 'unknown',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sensor_type (sensor_type),
    INDEX idx_created_at (created_at)
);

-- Create system_logs table for general logging
CREATE TABLE IF NOT EXISTS system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(100),
    log_level ENUM('info', 'warning', 'error', 'debug') DEFAULT 'info',
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_device_id (device_id),
    INDEX idx_log_level (log_level),
    INDEX idx_created_at (created_at)
);

-- Insert sample data for testing sensor readings
INSERT INTO sensor_readings (sensor_type, value, unit, location) VALUES 
('temperature', 25.5, '°C', 'Office Room'),
('humidity', 65.2, '%', 'Office Room'),
('light', 850, 'lux', 'Laboratory'),
('motion', 1, 'detected', 'Workshop');
