const axios = require('axios');

const serverUrl = 'http://localhost:3000';
const deviceId = 'test_controller_001';

async function testRelayEndpoints() {
    console.log('🧪 Testing Relay Control Endpoints\n');

    try {
        // Test 1: Server status
        console.log('1️⃣ Testing server status...');
        const statusResponse = await axios.get(`${serverUrl}/status`);
        console.log(`✅ Server status: ${statusResponse.data.status}`);
        console.log(`   Database: ${statusResponse.data.database}`);
        console.log(`   Timestamp: ${statusResponse.data.timestamp}\n`);

        // Test 2: Trigger relay 1
        console.log('2️⃣ Testing relay 1 trigger...');
        const triggerResponse = await axios.post(`${serverUrl}/relay/1/trigger`, {
            device_id: deviceId,
            duration: 3000
        });
        console.log(`✅ Relay 1 triggered successfully!`);
        console.log(`   ID: ${triggerResponse.data.id}`);
        console.log(`   Action: ${triggerResponse.data.action}`);
        console.log(`   Duration: ${triggerResponse.data.duration}ms\n`);

        // Test 3: Trigger relay 2
        console.log('3️⃣ Testing relay 2 trigger...');
        const trigger2Response = await axios.post(`${serverUrl}/relay/2/trigger`, {
            device_id: deviceId
        });
        console.log(`✅ Relay 2 triggered successfully!`);
        console.log(`   ID: ${trigger2Response.data.id}\n`);

        // Test 4: Get relay status
        console.log('4️⃣ Testing relay status endpoint...');
        const statusResponse2 = await axios.get(`${serverUrl}/relay/status`, {
            params: {
                device_id: deviceId,
                limit: 5
            }
        });
        console.log(`✅ Relay status retrieved successfully!`);
        console.log(`   Found ${statusResponse2.data.relay_controls.length} control records:`);
        statusResponse2.data.relay_controls.forEach((record, index) => {
            console.log(`   ${index + 1}. Relay ${record.relay_number} - ${record.action} at ${record.controlled_at}`);
        });
        console.log();

        // Test 5: Reset relay 1
        console.log('5️⃣ Testing relay 1 reset...');
        const resetResponse = await axios.post(`${serverUrl}/relay/1/reset`, {
            device_id: deviceId
        });
        console.log(`✅ Relay 1 reset successfully!`);
        console.log(`   ID: ${resetResponse.data.id}\n`);

        // Test 6: Control all relays
        console.log('6️⃣ Testing all relays control...');
        const allResponse = await axios.post(`${serverUrl}/relay/all`, {
            device_id: deviceId,
            action: 'trigger_all',
            duration: 3000
        });
        console.log(`✅ All relays controlled successfully!`);
        console.log(`   Action: ${allResponse.data.action}`);
        console.log(`   Affected relays: ${allResponse.data.affected_relays.join(', ')}\n`);

        // Test 7: Error handling - invalid relay number
        console.log('7️⃣ Testing error handling (invalid relay)...');
        try {
            await axios.post(`${serverUrl}/relay/5/trigger`, {
                device_id: deviceId
            });
            console.log(`❌ Should have failed with invalid relay number`);
        } catch (error) {
            console.log(`✅ Correctly rejected invalid relay number`);
            console.log(`   Error: ${error.response.data.error}\n`);
        }

        // Test 8: Error handling - missing device_id
        console.log('8️⃣ Testing error handling (missing device_id)...');
        try {
            await axios.post(`${serverUrl}/relay/1/trigger`, {});
            console.log(`❌ Should have failed with missing device_id`);
        } catch (error) {
            console.log(`✅ Correctly rejected missing device_id`);
            console.log(`   Error: ${error.response.data.error}\n`);
        }

        console.log('🎉 All tests completed successfully!');
        console.log('\n📊 Summary:');
        console.log('- ✅ Server status check');
        console.log('- ✅ Individual relay trigger');
        console.log('- ✅ Relay status retrieval');
        console.log('- ✅ Relay reset');
        console.log('- ✅ All relays control');
        console.log('- ✅ Error handling validation');

    } catch (error) {
        console.error('❌ Test failed:', error.message);
        if (error.response) {
            console.error('Response data:', error.response.data);
            console.error('Response status:', error.response.status);
        }
    }
}

// Run the tests
testRelayEndpoints();