# TODO - Refactor to Remove Tables

## Completed:
- [x] Analyze codebase and create plan

## In Progress:
- [ ] Update database_schema.sql - Remove tables (devices, relay_controls, led_controls)
- [ ] Update server.js - Remove endpoints that use removed tables
- [ ] Update test-api.js - Remove tests for deleted endpoints
- [ ] Verify changes

## Details:
### database_schema.sql:
- Remove devices table
- Remove led_controls table  
- Remove relay_controls table
- Remove sample data for devices
- Keep: sensor_readings, system_logs

### server.js:
- Remove POST /device/register
- Remove GET /device/:device_id/status
- Remove POST /led/control
- Remove POST /relay/:relay_number/trigger
- Remove POST /relay/:relay_number/reset
- Remove GET /relay/status
- Remove POST /relay/all

### test-api.js:
- Remove POST /device/register test
